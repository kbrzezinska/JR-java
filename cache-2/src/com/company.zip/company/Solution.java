package com.company;

import java.util.ArrayList;

public class Solution {
    public ArrayList<Item>solutonitems;
    public double maxValue;

    public Solution(ArrayList list,double value)
    {
        solutonitems=new ArrayList<>();
        this.solutonitems=list;
        this.maxValue=value;

    }

}
